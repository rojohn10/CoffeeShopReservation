SET IDENTITY_INSERT [dbo].[Menus] ON
INSERT INTO [dbo].[Menus] ([Id], [Name], [Image]) VALUES (1, N'Coffee', N'https://i.imgur.com/32myl6t.jpg')
INSERT INTO [dbo].[Menus] ([Id], [Name], [Image]) VALUES (2, N'Tea', N'https://i.imgur.com/BbJvKUl.jpg')
INSERT INTO [dbo].[Menus] ([Id], [Name], [Image]) VALUES (3, N'Cold Drinks', N'https://i.imgur.com/Rfvwsti.jpg')
SET IDENTITY_INSERT [dbo].[Menus] OFF
